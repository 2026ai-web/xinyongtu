import {spawn} from 'node:child_process';

const url='http://127.0.0.1:17411/';
let existing=false;
try {
  const response=await fetch(url+'api/health',{signal:AbortSignal.timeout(1200)});
  const health=await response.json();
  existing=response.ok && health.app==='xinyongtu-local-workbench' && health.version==='0.2.0' && health.ready===true;
}catch{}
if(existing){
  console.log('Workbench is already running. Opening existing window.');
  if(process.platform==='win32')spawn('explorer.exe',[url],{stdio:'ignore'}).on('error',()=>console.log(url));
}else{
  process.env.PORT='17411';
  process.argv.push('--open');
  await import('./server.mjs');
}
