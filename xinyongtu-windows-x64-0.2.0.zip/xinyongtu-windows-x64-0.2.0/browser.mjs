import { chromium } from 'playwright-core';
import { join } from 'node:path';
import { homedir } from 'node:os';

// Dedicated profile only. Never attach to a daily-use Chrome or export cookies.
export function createBrowserConnection(options = {}) {
  let context=null, opening=null;
  const profile=options.profile || join(process.env.LOCALAPPDATA || join(homedir(),'.local','share'),'Xinyongtu','ChromeProfile');
  const settings=options.launchOptions || {channel:'chrome',headless:false};
  const landing=options.landing || 'https://mms.pinduoduo.com/';
  async function status(){
    if(!context)return {connected:false,loginVerified:false,message:'专用浏览器未连接'};
    const pages=context.pages();
    const merchantPages=pages.filter(p=>{try{return new URL(p.url()).hostname==='mms.pinduoduo.com'}catch{return false}});
    return {connected:true,loginVerified:false,pageCount:pages.length,merchantPageCount:merchantPages.length,
      message:merchantPages.length?'已连接商家站点页面，登录状态尚未验证':'浏览器已连接，请在专用窗口打开商家后台'};
  }
  async function open(){
    if(opening)return opening;
    if(context){const page=context.pages()[0];if(page)await page.bringToFront();return status();}
    opening=(async()=>{
      try{
        const launched=await chromium.launchPersistentContext(profile,settings);
        context=launched;launched.on('close',()=>{if(context===launched)context=null});
        const page=launched.pages()[0] || await launched.newPage();
        await page.goto(landing,{waitUntil:'domcontentloaded',timeout:30000}).catch(()=>{});
        return status();
      }catch{
        throw new Error('无法启动专用 Chrome。请确认已安装 Google Chrome，且没有另一个助手正在使用该专用配置。');
      }finally{opening=null;}
    })();return opening;
  }
  async function close(){if(opening)await opening.catch(()=>{});if(context)await context.close();return status();}
  return {open,status,close};
}
