import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { analyzeOrders, analyzePromotion } from './reports.mjs';
import { createBrowserConnection } from './browser.mjs';
const browser=createBrowserConnection();
const page = new URL('./public/index.html', import.meta.url);
http.createServer(async (req, res) => {
  res.setHeader('Cache-Control','no-store');
  res.setHeader('X-Content-Type-Options','nosniff');
  const host=req.headers.host||'';
  if(!/^(localhost|127\.0\.0\.1):\d+$/.test(host) || (req.headers.origin && req.headers.origin!==`http://${host}`)) {res.writeHead(403);return res.end('Invalid origin');}
  if(req.url==='/api/health' && req.method==='GET') {res.setHeader('Content-Type','application/json');return res.end(JSON.stringify({app:'xinyongtu-local-workbench',version:'0.2.0',ready:true}));}
  if(req.url.startsWith('/api/browser/')) {
    res.setHeader('Content-Type','application/json; charset=utf-8');
    const action=req.url.slice('/api/browser/'.length);
    if(!['open','close','status'].includes(action)){res.writeHead(404);return res.end('{}');}
    if(req.method!=='POST'||req.headers['x-workbench-upload']!=='1'){res.writeHead(403);return res.end('{}');}
    try{res.end(JSON.stringify(await browser[action]()));}catch(error){res.writeHead(503);res.end(JSON.stringify({error:error.message}));}return;
  }
  if(['/api/orders','/api/promotion'].includes(req.url)) {
    res.setHeader('Content-Type','application/json; charset=utf-8');
    if(req.method!=='POST'){res.writeHead(405);return res.end('{}');}
    if(req.headers['x-workbench-upload']!=='1'){res.writeHead(403);return res.end('{}');}
    try {
      let size=0;const chunks=[];
      for await(const chunk of req){size+=chunk.length;if(size>2097152){res.writeHead(413);return res.end(JSON.stringify({error:'文件超过 2 MB'}));}chunks.push(chunk);}
      const data=(req.url==='/api/orders'?analyzeOrders:analyzePromotion)(Buffer.concat(chunks));
      res.writeHead(200);return res.end(JSON.stringify(data));
    }catch(error){res.writeHead(422);return res.end(JSON.stringify({error:/订单|报表|时段|分时|请上传|缺少/.test(error.message)?error.message:'文件解析失败，请核对格式和字段'}));}
  }
  if(req.url==='/app.js' && req.method==='GET') {res.setHeader('Content-Type','text/javascript; charset=utf-8');return res.end(await readFile(new URL('./public/app.js',import.meta.url)));}
  if (req.url !== '/' && req.url !== '/index.html') { res.writeHead(404); return res.end('Not found'); }
  try { res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store'}); res.end(await readFile(page)); }
  catch { res.writeHead(500); res.end('Page unavailable'); }
}).on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? 'Port already in use. Close the previous instance or set PORT to another port.' : error.message);
  process.exitCode = 1;
}).listen(Number(process.env.PORT || 3000), '127.0.0.1', function () {
  const url = `http://127.0.0.1:${this.address().port}/`;
  console.log(`Xinyongtu running at ${url}. Keep this terminal open. Press Ctrl+C to stop.`);
  if (process.argv.includes('--open') && process.platform === 'win32') {
    const opener = spawn('explorer.exe', [url], {stdio: 'ignore'});
    opener.on('error', () => console.error('Could not open browser. Open the address printed above manually.'));
  }
});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,async()=>{await browser.close();process.exit(0)});
