export const merchantHosts = new Set(['mms.pinduoduo.com','yingxiao.pinduoduo.com']);
export function isMerchantUrl(url) { try {const u=new URL(url);return u.protocol==='https:' && merchantHosts.has(u.hostname);}catch{return false;} }

// Serialized into a page by Playwright. Read-only DOM inspection, no requests or clicks.
// Return only known promotion labels/numbers, not arbitrary page text or credentials.
export function collectPromotionDocument() {
  if(location.protocol!=='https:' || !['mms.pinduoduo.com','yingxiao.pinduoduo.com'].includes(location.hostname))return {recognized:false,reason:'不支持的站点'};
  const labels=['总花费(元)','成交花费(元)','交易额(元)','净交易额(元)','实际投产比','净实际投产比','净成交笔数','成交笔数','每笔净成交花费(元)','曝光量','点击量','点击率','点击转化率','预算日限额(元)','净目标投产比','总预算日限额','总净目标投产比'];
  const normalize=s=>s.replace(/\s/g,'').replace(/（/g,'(').replace(/）/g,')').replace(/[：:]$/,'');
  const visible=e=>e instanceof Element && e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}) && (()=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth;})();
  const tokens=[];
  if(!document.body)return {recognized:false,reason:'页面尚未加载'};
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  let node,visited=0;
  while((node=walker.nextNode()) && visited++<50000) {
    const e=node.parentElement;
    if(!e || ['SCRIPT','STYLE','NOSCRIPT','TEXTAREA'].includes(e.tagName) || !visible(e))continue;
    const value=node.textContent.trim();if(value)tokens.push({e,value});
  }
  const text=tokens.map(t=>t.value).join('\n');
  const scopedText=e=>tokens.filter(t=>e.contains(t.e)).map(t=>t.value).join('\n');
  const loginVisible=tokens.some(t=>['扫码登录','账号登录','短信登录','请先登录'].includes(t.value)) || [...document.querySelectorAll('input[type=password]')].some(visible);
  if(loginVisible)return {recognized:false,reason:'当前可见登录提示，请在当前标签页完成登录后重试'};
  const knownPromotionPath=/^\/goods\/promotion(?:\/|$)/.test(location.pathname);
  if(!(knownPromotionPath||/商品推广|多多招财/.test(text)) || !/稳定成本推广|全店托管|净目标投产比/.test(text))return {recognized:false,reason:'当前可见区域未识别到多多招财，请打开推广页面'};
  const metrics=[];
  const metricElements=new Map();
  const rowSelector='tr,[role="row"],[class*="table-row"],[class*="TableRow"]';
  for(const {e,value} of tokens) {
    const label=labels.find(l=>normalize(l)===normalize(value));if(!label)continue;
    if(e.closest(rowSelector))continue; // Table rows are parsed separately; never treated as summary cards.
    let parent=e;
    for(let depth=0;parent && parent!==document.body && depth<5;depth++,parent=parent.parentElement){
      const card=tokens.filter(t=>parent.contains(t.e)).map(t=>t.value).join('\n');if(card.length>250)break;
      const marker=normalize(label), pos=card.indexOf(value);
      if(pos<0)continue;
      const rest=card.slice(pos+value.length).trimStart();
      if(labels.some(l=>normalize(l)!==marker && normalize(rest).includes(normalize(l))))break;
      // First value must immediately follow the label, not a distant table row or other field.
      const match=/^[¥￥]?(-?\d[\d,]*(?:\.\d+)?)(万|亿)?(%?)/.exec(rest);
      if(!match)continue;
      const r=e.getBoundingClientRect();
      const current=match[1]+(match[2]||'')+(match[3]||'');
      if(!metrics.some(m=>m.label===label && m.current===current && Math.abs(m.top-r.top)<3)){
        const metric={label,current,top:Math.round(r.top)};metrics.push(metric);metricElements.set(metric,e);
      }
      break;
    }
  }
  const dateCandidates=[...new Set([...text.matchAll(/\b20\d{2}[/-]\d{1,2}[/-]\d{1,2}\b/g)].map(m=>m[0]))].slice(0,6);
  for(const input of document.querySelectorAll('input')){
    if(visible(input) && /^20\d{2}[/-]\d{1,2}[/-]\d{1,2}$/.test(input.value) && !dateCandidates.includes(input.value))dateCandidates.push(input.value);
  }
  const currentCutoffs=[],comparisonCutoffs=[];
  for(const match of text.matchAll(/(今日|今天|昨日|昨天)\s*截至\s*((?:[01]?\d|2[0-3]):[0-5]\d)/g)){
    const target=/今日|今天/.test(match[1])?currentCutoffs:comparisonCutoffs;
    if(!target.includes(match[2]))target.push(match[2]);
  }
  const dataAsOf={currentCutoffs,comparisonCutoffs,
    cutoffAlignment:currentCutoffs.length===1&&comparisonCutoffs.length===1?(currentCutoffs[0]===comparisonCutoffs[0]?'same':'different'):'unknown',
    note:'只记录页面显示的数据截止时点；时点相同也不代表归因、退款和统计范围完全一致。'};
  const products=[],pendingRows=[],seenRows=new Set();
  const idPattern=/商品\s*ID\s*[:：]\s*(\d{6,20})(?!\d)/gi;
  const rowFieldLabels=['成交花费(元)','交易额(元)','实际投产比','总花费(元)','净交易额(元)','净实际投产比','净成交笔数','每笔净成交花费(元)','曝光量','点击量'];
  const numeric=value=>{
    const match=/^[¥￥]?(-?\d[\d,]*(?:\.\d+)?)(万|亿)?(%?)(?:\s|元|$)/.exec(value.trim());
    return match?match[1]+(match[2]||'')+(match[3]||''):null;
  };
  for(const {e,value} of tokens){
    if(!/商品\s*ID\s*[:：]/i.test(value))continue;
    let row=e.closest(rowSelector);
    if(!row){
      let parent=e;
      for(let depth=0;parent&&parent!==document.body&&depth<8;depth++,parent=parent.parentElement){
        const candidate=scopedText(parent);
        if(candidate.length>3000)break;
        if([...candidate.matchAll(idPattern)].length===1&&/预算日限额|净目标投产比/.test(candidate)){row=parent;break;}
      }
    }
    if(!row){pendingRows.push({reason:'发现商品ID标记，但未识别唯一行边界'});continue;}
    if(seenRows.has(row))continue;seenRows.add(row);
    const rowText=scopedText(row),ids=[...rowText.matchAll(idPattern)].map(m=>m[1]);
    if(ids.length!==1){pendingRows.push({reason:'行内商品ID不唯一，未绑定指标'});continue;}
    const productId=ids[0];
    const budgetMatch=/预算日限额\s*(?:[（(]元[）)])?\s*[:：]?\s*(不限|\d[\d,]*(?:\.\d+)?)/.exec(rowText);
    const roasMatch=/净目标投产比\s*[:：]?\s*(\d+(?:\.\d+)?)/.exec(rowText);
    const budget=budgetMatch?{kind:budgetMatch[1]==='不限'?'unlimited':'amount',display:budgetMatch[1],currency:'CNY'}:null;
    const targetNetRoas=roasMatch?roasMatch[1]:null;
    const statusMatch=/(?:^|\s)(推广中|手动暂停|已暂停|已结束|推广受限)(?:\s|$)/.exec(rowText);
    const fields=[];
    const table=row.closest('table,[role="table"],[role="grid"]');
    let mapping='unavailable';
    if(table){
      const headers=[...table.querySelectorAll('thead tr:last-child th,[role="columnheader"]')];
      const cells=[...row.children].filter(c=>['TD','TH'].includes(c.tagName)||c.getAttribute('role')==='cell'||c.getAttribute('role')==='gridcell');
      if(headers.length&&headers.length===cells.length&&headers.every(h=>(h.colSpan||1)===1&&(h.rowSpan||1)===1)){
        mapping='visible-column-headers';
        headers.forEach((header,i)=>{
          if(!visible(header)||!visible(cells[i]))return;
          const name=normalize(scopedText(header));
          const label=rowFieldLabels.find(l=>normalize(l)===name);if(!label)return;
          const value=numeric(scopedText(cells[i]));if(value!==null)fields.push({label,current:value});
        });
      }
    }
    products.push({productId,status:statusMatch?statusMatch[1]:null,budget,targetNetRoas,metrics:fields,
      mapping,top:Math.round(row.getBoundingClientRect().top),verification:'pending',
      missingFields:[...(!budget?['预算日限额']:[]),...(!targetNetRoas?['净目标投产比']:[]),...rowFieldLabels.filter(l=>!fields.some(f=>f.label===l))]});
    if(products.length>=50)break;
  }
  const duplicateIds=products.filter((p,i)=>products.findIndex(x=>x.productId===p.productId)!==i).map(p=>p.productId);
  const warnings=['识别到推广页面不等于已验证店铺身份。','采集值仅供人工核对，不自动加入利润计算或形成调价指令。','同名指标可能来自不同区域；日期可能包含对比日期，均不可自动合并。'];
  if(dataAsOf.cutoffAlignment==='different')warnings.push('当前日与对比日截止时点不同，禁止直接按汇总值做同比判断。');
  if(duplicateIds.length)warnings.push('检测到重复商品ID，不自动合并重复行。');
  const summaryMetrics=metrics.filter(m=>![...seenRows].some(row=>row.contains(metricElements.get(m))));
  return {schemaVersion:'0.5.0',recognized:true,metrics:summaryMetrics.slice(0,100),dateCandidates:dateCandidates.slice(0,6),dataAsOf,
    products,pendingRows,duplicateIds,productScope:'仅本次可见行与可见列；不包含未滚动到的行、隐藏列或其他分页。',
    scope:'当前窗口可见区域；未滚动、未切换日期、未点击按钮',loginVerified:false,
    warnings};
}
