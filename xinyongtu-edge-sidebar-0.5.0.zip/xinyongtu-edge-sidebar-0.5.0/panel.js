import {collectPromotionDocument,isMerchantUrl} from './reader.js';
const $=id=>document.getElementById(id);let snapshot=null,revision=0,targetTab=null;
function node(tag,text){const e=document.createElement(tag);e.textContent=text;return e;}
function reset(message='页面已改变，请重新采集。'){
 revision++;snapshot=null;$('results').hidden=true;$('export').disabled=true;$('status').textContent=message;
}
function display(data){
 snapshot=data;$('results').hidden=false;$('time').textContent='采集时间：'+new Date(data.capturedAt).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'})+'（北京时间）';
 $('dates').textContent='日期候选：'+(data.dateCandidates.join('、')||'未识别')+'。统计日期与对比日期需人工区分。';
 const asOf=data.dataAsOf||{};
 $('asOf').textContent='当前日截止：'+((asOf.currentCutoffs||[]).join('、')||'未识别')+'；对比日截止：'+((asOf.comparisonCutoffs||[]).join('、')||'未识别')+'。'+(asOf.cutoffAlignment==='different'?'时点不同，不能直接同比。':asOf.cutoffAlignment==='same'?'时点一致，仍需核对统计范围。':'截止时点无法完整核对。');
 $('productScope').textContent=data.productScope||'尚未识别商品行';$('products').replaceChildren();
 for(const product of data.products||[]){
  const block=document.createElement('div');block.className='product';block.append(node('h3','商品 ID：'+product.productId));
  block.append(node('p','状态：'+(product.status||'未识别')+' · 预算：'+(product.budget?product.budget.display+(product.budget.kind==='amount'?' 元':''):'未识别')+' · 净目标投产比：'+(product.targetNetRoas||'未识别')));
  const list=document.createElement('dl');for(const field of product.metrics){list.append(node('dt',field.label),node('dd',field.current));}block.append(list);
  block.append(node('p',product.metrics.length?'同行指标待核对；不能与顶部汇总合并。':'未匹配到可靠列头，未猜测这条商品的花费或成交数据。'));
  block.append(node('p','本次缺失：'+product.missingFields.join('、')));$('products').append(block);
 }
 if(!(data.products||[]).length)$('products').append(node('p','当前未识别商品行。请手动将列表和列头滚动到可见位置，再采集；不会自动翻页。'));
 for(const row of data.pendingRows||[])$('products').append(node('p','待核对：'+row.reason));
 const counts=Object.create(null);for(const m of data.metrics)counts[m.label]=(counts[m.label]||0)+1;
 $('metrics').replaceChildren();
 for(const m of data.metrics){const tr=document.createElement('tr');for(const v of[m.label,m.current,counts[m.label]>1?'多个候选，不可合并':'待人工核对'])tr.append(node('td',v));$('metrics').append(tr);}
 $('warnings').replaceChildren();
 if(!data.metrics.length)$('warnings').append(node('p','页面已识别，但未解析到数据卡片。请将指标显示在窗口中再试，不会将缺失值记成零。'));
 for(const warning of data.warnings)$('warnings').append(node('p',warning));
 $('export').disabled=false;
}
$('read').onclick=async()=>{
 reset('正在只读采集当前标签页…');const ticket=revision;$('read').disabled=true;
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!isMerchantUrl(tab.url))throw Error('请先选中日常 Edge 中的拼多多商家后台或多多招财标签页，再点击采集。');
  if(tab.status==='loading')throw Error('页面正在加载，请稍后重试。');
  targetTab=tab.id;
  const results=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:collectPromotionDocument});
  if(ticket!==revision)return;
  const current=await chrome.tabs.get(tab.id);
  if(current.url!==tab.url||current.status==='loading')throw Error('页面已跳转，请加载完成后重新采集。');
  const recognized=results.map(r=>r.result).filter(r=>r?.recognized);
  if(!recognized.length)throw Error('未识别到可见的多多招财数据。请确认已登录，打开“商品推广”，并将数据卡片显示在当前窗口。');
  if(recognized.length!==1)throw Error('页面存在多个推广区域，暂不自动合并。请只显示一个待核对的推广页面后重试。');
  display({...recognized[0],capturedAt:new Date().toISOString(),readOnly:true,source:'daily-edge-sidebar',origin:new URL(tab.url).origin});
  $('status').textContent='采集完成，数据待核对；没有修改推广。';
 }catch(e){if(ticket===revision)$('status').textContent=/Cannot access|permission|Extension manifest/i.test(e.message)?'无法读取此页面。请确认扩展已获得拼多多站点权限；扩展更新后请刷新推广标签页再试。':e.message;}
 finally{$('read').disabled=false;}
};
$('clear').onclick=()=>reset('本次数据已清除。');
$('export').onclick=()=>{
 if(!snapshot)return;
 const url=URL.createObjectURL(new Blob([JSON.stringify(snapshot,null,2)],{type:'application/json'}));
 const a=document.createElement('a');a.href=url;a.download='xinyongtu-edge-readonly.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
};
chrome.tabs.onActivated.addListener(()=>reset('当前标签页已切换，请重新采集。'));
chrome.tabs.onUpdated.addListener((id,change)=>{if(id===targetTab&&(change.status==='loading'||change.url))reset('推广页面已跳转或刷新，请重新采集。');});
