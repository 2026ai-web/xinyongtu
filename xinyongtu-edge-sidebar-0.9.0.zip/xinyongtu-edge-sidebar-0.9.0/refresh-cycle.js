import {collectPromotionDocument,isMerchantUrl} from './reader.js';
export function promotionScope(data){
 if(!data?.recognized||!data.dateScopes?.primaryVerified||!['稳定成本推广','全店托管'].includes(data.activeMode)||!data.scopeFingerprint||!data.selectedDateRange?.length){const error=Error('刷新前后无法可靠确认推广模式、日期或筛选范围');error.code='scope-unverified';throw error;}
 return {origin:data.origin,mode:data.activeMode,dates:[...data.selectedDateRange].sort(),comparison:[...(data.dateScopes.comparison||[])].sort(),filter:data.scopeFingerprint};
}
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
export function assertPromotionScope(expected,data){const actual=promotionScope(data);if(!same(expected,actual))throw Error('刷新前后推广模式、日期或筛选范围发生变化；请在平台确认范围后重新开始');return actual;}
// Reload only the currently selected merchant tab, never navigate to a constructed URL.
// A changed document marker proves reload completed; equal data is not proof of freshness.
export async function prepareRefreshedPage({tabId,signal,baseline=null,onPhase=()=>{},timeoutMs=20000,pollMs=250,settleMs=500}){
 const evidence={requested:true,attempted:false,documentReloadConfirmed:false,startedAt:new Date().toISOString(),before:null,after:null};
 const deadline=Date.now()+timeoutMs;let originalUrl;
 const sleep=()=>new Promise(resolve=>setTimeout(resolve,pollMs));
 async function check(){
  if(signal.aborted)throw Error('采集已停止');if(Date.now()>deadline)throw Error('页面刷新或范围校验超时，请等页面加载完成后重试');
  const [active]=await chrome.tabs.query({active:true,currentWindow:true});const tab=await chrome.tabs.get(tabId);
  if(active?.id!==tabId||!isMerchantUrl(tab.url))throw Error('当前标签或站点已改变，停止刷新采集');
  if(originalUrl&&tab.url!==originalUrl)throw Error('刷新期间页面地址改变，可能跳转登录，请确认页面后重新开始');
  return tab;
 }
 async function marker(){const [r]=await chrome.scripting.executeScript({target:{tabId,frameIds:[0]},func:()=>performance.timeOrigin});return r?.result;}
 async function read(){
  const rs=await chrome.scripting.executeScript({target:{tabId,allFrames:true},func:collectPromotionDocument,args:[{includeOffscreen:true}]});
  const matches=rs.filter(r=>r.result?.recognized);if(matches.length!==1){const error=Error('未唯一识别推广页面，可能未登录或尚未加载完成');error.code=matches.length>1?'ambiguous-frame':rs.some(r=>/登录/.test(r.result?.reason||''))?'login-required':'page-not-ready';throw error;}return matches[0].result;
 }
 async function waitScopedRead(){
  for(;;){await check();try{const data=await read();promotionScope(data);return data;}catch(error){if(!['page-not-ready','scope-unverified'].includes(error.code))throw error;}await sleep();}
 }
 async function waitReady(oldMarker){
  let readySince=null;
  for(;;){
   const tab=await check();let changed=oldMarker===undefined;
   if(tab.status!=='loading'){
    if(oldMarker!==undefined){try{const m=await marker();changed=typeof m==='number'&&m!==oldMarker;}catch{changed=false;}}
    if(changed){readySince??=Date.now();if(Date.now()-readySince>=settleMs)return;}else readySince=null;
   }else readySince=null;
   await sleep();
  }
 }
 try{
  onPhase('正在核对刷新前的推广范围…');const initial=await check();originalUrl=initial.url;await waitReady();
  const before=await waitScopedRead();await check();const scope=promotionScope(before);evidence.before=scope;evidence.beforeCutoffs=before.dataAsOf;
  if(baseline)assertPromotionScope(baseline,before);
  const oldMarker=await marker();if(typeof oldMarker!=='number')throw Error('无法确认页面文档，未执行刷新');
  await check();onPhase('正在刷新当前推广页面，等待加载完成…');evidence.attempted=true;await chrome.tabs.reload(tabId);
  await waitReady(oldMarker);evidence.documentReloadConfirmed=true;
  onPhase('页面已刷新，正在核对日期、模式和筛选范围…');
  const after=await waitScopedRead();await check();evidence.after={origin:after.origin,mode:after.activeMode,dates:after.selectedDateRange,comparison:after.dateScopes?.comparison||[],filter:after.scopeFingerprint};evidence.afterCutoffs=after.dataAsOf;
  assertPromotionScope(scope,after);
  await sleep();await check();const confirmed=await read();assertPromotionScope(scope,confirmed);
  evidence.afterCutoffs=confirmed.dataAsOf;evidence.finishedAt=new Date().toISOString();
  const old=before.dataAsOf?.currentCutoffs||[],fresh=confirmed.dataAsOf?.currentCutoffs||[];
  evidence.cutoffChanged=old.length===1&&fresh.length===1?old[0]!==fresh[0]:null;
  return {scope,evidence};
 }catch(error){evidence.finishedAt=new Date().toISOString();evidence.error=error.message;error.refreshEvidence=evidence;throw error;}
}
export function refreshFailureDiagnostic(error){
 const info=error.refreshEvidence||{},scope=info.before||{};
 return {schemaVersion:'0.9.0',recognized:false,origin:scope.origin||'',activeMode:scope.mode||null,selectedDateRange:scope.dates||[],dateScopes:{primary:scope.dates||[],primaryVerified:false},scopeFingerprint:scope.filter||'',metrics:[],products:[],pendingRows:[],conflictProductIds:[],warnings:[error.message],capturedAt:new Date().toISOString(),readOnly:true,source:'daily-edge-sidebar-refresh-failed',refreshEvidence:info,
 autoCollection:{scanCompleted:false,expectedRows:null,capturedRows:0,rowCoverageConfirmed:false,dateRangeVerified:false,fieldsComplete:false,stopReason:error.message}};
}
