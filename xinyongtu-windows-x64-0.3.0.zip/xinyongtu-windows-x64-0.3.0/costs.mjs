// Confirmed merchant assumptions. Amounts use integer fen; rates use basis points.
export const costPolicy = Object.freeze({
  gloveFen: 29, shippingFen: 200, laborFen: 50, insuranceFen: 30,
  platformFeeBps: 350,
});

function integer(value, name, min = 0) {
  if (!Number.isSafeInteger(value) || value < min) throw new Error(`Invalid ${name}`);
  return value;
}

export function parseSku(code) {
  const match = /^HR-黑钻石纹(M|L|XL)-(10|20|30|50|100)$/.exec(code.trim());
  if (!match) throw new Error('Unknown SKU: manual cost mapping required');
  return { size: match[1], glovesPerPack: Number(match[2]) };
}

export function estimateOrderCost({sku, packs = 1, revenueFen, fulfillment = 'shipped', refunded = false}) {
  const {glovesPerPack} = parseSku(sku);
  integer(packs, 'packs', 1);
  integer(revenueFen, 'revenueFen');
  if (!['shipped', 'unshipped'].includes(fulfillment)) throw new Error('Unknown fulfillment');
  if (fulfillment === 'unshipped') {
    if (!refunded) throw new Error('Unshipped active orders require separate pending accounting');
    return {goodsFen: 0, shippingFen: 0, packagingFen: 0, laborFen: 0,
      insuranceFen: 0, platformFeeFen: null, totalFen: null,
      status: 'refund_fee_reconciliation_required'};
  }
  const goodsFen = glovesPerPack * packs * costPolicy.gloveFen;
  integer(goodsFen, 'goodsFen');
  // Multi-pack packaging and parcel counts have not been confirmed by the merchant.
  if (packs !== 1) throw new Error('Multi-pack shipping and packaging require manual confirmation');
  const packagingFen = glovesPerPack <= 30 ? 30 : glovesPerPack === 50 ? 50 : 100;
  const platformFeeFen = refunded ? null : Math.round(revenueFen * costPolicy.platformFeeBps / 10000);
  const fixedFen = goodsFen + costPolicy.shippingFen + packagingFen + costPolicy.laborFen + costPolicy.insuranceFen;
  return {goodsFen, shippingFen: costPolicy.shippingFen, packagingFen,
    laborFen: costPolicy.laborFen, insuranceFen: costPolicy.insuranceFen,
    platformFeeFen, totalFen: platformFeeFen === null ? null : fixedFen + platformFeeFen,
    status: refunded ? 'refund_and_goods_reconciliation_required' : 'estimated'};
}
