export const merchantHosts = new Set(['mms.pinduoduo.com','yingxiao.pinduoduo.com']);
export function isMerchantUrl(url) { try {const u=new URL(url);return u.protocol==='https:' && merchantHosts.has(u.hostname);}catch{return false;} }

// Serialized into a page by Playwright. Read-only DOM inspection, no requests or clicks.
// Return only known promotion labels/numbers, not arbitrary page text or credentials.
export function collectPromotionDocument() {
  const labels=['总花费(元)','成交花费(元)','交易额(元)','净交易额(元)','实际投产比','净实际投产比','净成交笔数','成交笔数','每笔净成交花费(元)','曝光量','点击量','点击率','点击转化率','预算日限额(元)','净目标投产比','总预算日限额','总净目标投产比'];
  const normalize=s=>s.replace(/\s/g,'').replace(/（/g,'(').replace(/）/g,')').replace(/[：:]$/,'');
  const visible=e=>e instanceof Element && e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}) && (()=>{const r=e.getBoundingClientRect();return r.width>0&&r.height>0&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth;})();
  const tokens=[];
  if(!document.body)return {recognized:false,reason:'页面尚未加载'};
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  let node,visited=0;
  while((node=walker.nextNode()) && visited++<50000) {
    const e=node.parentElement;
    if(!e || ['SCRIPT','STYLE','NOSCRIPT','TEXTAREA'].includes(e.tagName) || !visible(e))continue;
    const value=node.textContent.trim();if(value)tokens.push({e,value});
  }
  const text=tokens.map(t=>t.value).join('\n');
  const loginVisible=tokens.some(t=>['扫码登录','账号登录','短信登录','请先登录'].includes(t.value)) || [...document.querySelectorAll('input[type=password]')].some(visible);
  if(loginVisible)return {recognized:false,reason:'当前可见登录提示，请在专用窗口完成登录后重试'};
  if(!/商品推广|多多招财/.test(text) || !/稳定成本推广|全店托管|净目标投产比/.test(text))return {recognized:false,reason:'当前可见区域未识别到多多招财，请打开推广页面'};
  const metrics=[];
  for(const {e,value} of tokens) {
    const label=labels.find(l=>normalize(l)===normalize(value));if(!label)continue;
    let parent=e;
    for(let depth=0;parent && parent!==document.body && depth<5;depth++,parent=parent.parentElement){
      const card=tokens.filter(t=>parent.contains(t.e)).map(t=>t.value).join('\n');if(card.length>250)break;
      const marker=normalize(label), pos=card.indexOf(value);
      if(pos<0)continue;
      const rest=card.slice(pos+value.length).trimStart();
      if(labels.some(l=>normalize(l)!==marker && normalize(rest).includes(normalize(l))))break;
      // First value must immediately follow the label, not a distant table row or other field.
      const match=/^[¥￥]?(-?\d[\d,]*(?:\.\d+)?)(万|亿)?(%?)/.exec(rest);
      if(!match)continue;
      const r=e.getBoundingClientRect();
      const current=match[1]+(match[2]||'')+(match[3]||'');
      if(!metrics.some(m=>m.label===label && m.current===current && Math.abs(m.top-r.top)<3))metrics.push({label,current,top:Math.round(r.top)});
      break;
    }
  }
  const dateCandidates=[...new Set([...text.matchAll(/\b20\d{2}[/-]\d{1,2}[/-]\d{1,2}\b/g)].map(m=>m[0]))].slice(0,6);
  for(const input of document.querySelectorAll('input')){
    if(visible(input) && /^20\d{2}[/-]\d{1,2}[/-]\d{1,2}$/.test(input.value) && !dateCandidates.includes(input.value))dateCandidates.push(input.value);
  }
  return {recognized:true,metrics:metrics.slice(0,100),dateCandidates:dateCandidates.slice(0,6),
    scope:'当前窗口可见区域；未滚动、未切换日期、未点击按钮',loginVerified:false,
    warnings:['识别到推广页面不等于已验证店铺身份。','采集值仅供人工核对，不自动加入利润计算或形成调价指令。','同名指标可能来自不同区域；日期可能包含对比日期，均不可自动合并。']};
}
