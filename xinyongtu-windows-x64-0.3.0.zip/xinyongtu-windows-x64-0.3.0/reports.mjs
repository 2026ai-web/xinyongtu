import { parse } from 'csv-parse/sync';
import XLSX from 'xlsx';
import { estimateOrderCost } from './costs.mjs';

const clean = v => String(v ?? '').trim();
function number(value, label, integer = false) {
  const text = clean(value);
  if (!/^\d+(\.\d+)?$/.test(text)) throw new Error(`${label}不是有效的非负数字`);
  const n = Number(text);
  if (!Number.isFinite(n) || n > 1e9 || (integer && !Number.isSafeInteger(n))) throw new Error(`${label}超出范围`);
  return n;
}
const fen = (v, label) => Math.round(number(v, label) * 100);
export function analyzeOrders(buffer) {
  const text = new TextDecoder('utf-8', {fatal:true}).decode(buffer);
  const rows = parse(text, {bom:true, skip_empty_lines:true, max_record_size:100000});
  if (rows.length < 2 || rows.length > 20001) throw new Error('订单必须包含 1 至 20000 行');
  const headers = rows.shift().map(clean);
  if (new Set(headers).size !== headers.length) throw new Error('订单列名重复');
  const required = ['订单号','订单状态','商品数量(件)','商家编码-规格维度','售后状态','商家实收金额(元)'];
  for (const name of required) if (!headers.includes(name)) throw new Error(`缺少订单字段：${name}`);
  const at = (row, key) => clean(row[headers.indexOf(key)]);
  const states = Object.create(null), groups = new Map(), seen = new Set(), pending = Object.create(null);
  const result = {rows:rows.length, included:0, excluded:0, unresolved:0, revenueFen:0, totalCostFen:0,
    goodsFen:0, shippingFen:0, packagingFen:0, laborFen:0, insuranceFen:0, platformFeeFen:0};
  function unresolved(reason) { result.unresolved++; pending[reason]=(pending[reason]||0)+1; }
  for (const row of rows) {
    if (row.length !== headers.length) throw new Error('订单行列数不一致');
    const id=at(row,'订单号');
    if (!id || seen.has(id)) throw new Error('订单号为空或重复，请先核对多明细订单，避免重复分摊费用');
    seen.add(id);
    const state=at(row,'订单状态'), after=at(row,'售后状态');
    states[state]=(states[state]||0)+1;
    if (['待付款','已取消'].includes(state)) { result.excluded++; continue; }
    if (state==='未发货，退款成功') { result.excluded++; pending['未发货退款：运费险退回，平台扣费仍需账单核对']=(pending['未发货退款：运费险退回，平台扣费仍需账单核对']||0)+1; continue; }
    if (!['已发货，待收货','已收货','交易成功'].includes(state) || after!=='无售后或售后取消') {
      unresolved('状态或售后待核对；已发货退款的运费险不退'); continue;
    }
    let cost, revenue, packs;
    try {
      revenue=fen(at(row,'商家实收金额(元)'),'营业额');
      packs=number(at(row,'商品数量(件)'),'购买份数',true);
      cost=estimateOrderCost({sku:at(row,'商家编码-规格维度'),packs,revenueFen:revenue});
    } catch { unresolved('规格、数量或金额不能自动匹配成本'); continue; }
    result.included++; result.revenueFen+=revenue;
    for (const key of ['goodsFen','shippingFen','packagingFen','laborFen','insuranceFen','platformFeeFen']) result[key]+=cost[key];
    result.totalCostFen+=cost.totalFen;
    const sku=at(row,'商家编码-规格维度');
    const group=groups.get(sku)||{sku,orders:0,revenueFen:0,totalCostFen:0};
    group.orders++; group.revenueFen+=revenue; group.totalCostFen+=cost.totalFen; groups.set(sku,group);
  }
  return {...result,contributionFen:result.revenueFen-result.totalCostFen,states,pending,groups:[...groups.values()],
    date:null,productId:null,notice:'订单文件不含可验证的统计日期和商品ID，需人工绑定。不是最终到账利润；退款扣费、后续售后与其他费用尚待核对。'};
}

export function analyzePromotion(buffer) {
  // This workflow intentionally supports the merchant's legacy XLS export only.
  if (buffer.length<8 || !buffer.subarray(0,8).equals(Buffer.from('d0cf11e0a1b11ae1','hex'))) throw new Error('请上传平台原始 .xls 报表，不支持改扩展名或压缩文件');
  const book=XLSX.read(buffer,{type:'buffer',sheetRows:100,cellFormula:false,cellHTML:false,cellStyles:false});
  if (book.SheetNames.length!==1) throw new Error('报表工作表数量异常，请上传单个商品的分时报表');
  const rows=XLSX.utils.sheet_to_json(book.Sheets[book.SheetNames[0]],{header:1,defval:'',raw:false,blankrows:false});
  const head=(rows.shift()||[]).map(clean), date=head[0];
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || new Date(date+'T00:00:00Z').toISOString().slice(0,10)!==date) throw new Error('报表日期无效');
  if(new Set(head).size!==head.length) throw new Error('报表列名重复');
  const fields={spendFen:'总花费(元)',revenueFen:'交易额(元)',netRevenueFen:'净交易额(元)',orders:'成交笔数',netOrders:'净成交笔数',impressions:'曝光量',clicks:'点击量'};
  for(const name of Object.values(fields)) if(!head.includes(name)) throw new Error(`缺少报表字段：${name}`);
  const read=row=>Object.fromEntries(Object.entries(fields).map(([key,name])=>[key,key.endsWith('Fen')?fen(row[head.indexOf(name)],name):number(row[head.indexOf(name)],name,true)]));
  const totals=rows.filter(r=>clean(r[0])==='总计');
  if(totals.length!==1) throw new Error('报表必须包含唯一总计行');
  const total=read(totals[0]); const seen=new Set(); const hours=[];
  for(const row of rows.filter(r=>clean(r[0])!=='总计')){
    const match=/^(\d{1,2}):00-(\d{1,2}):00$/.exec(clean(row[0]));
    if(!match || +match[1]>23 || +match[2]!==+match[1]+1 || seen.has(+match[1])) throw new Error('时段重复或无效');
    seen.add(+match[1]); hours.push({hour:+match[1],...read(row)});
  }
  for(const key of Object.keys(fields)) if(hours.reduce((n,h)=>n+h[key],0)!==total[key]) throw new Error(`分时与总计不一致：${fields[key]}`);
  return {date,complete:seen.size===24,hourCount:seen.size,...total,hours:hours.sort((a,b)=>a.hour-b.hour),
    netRoas:total.spendFen?total.netRevenueFen/total.spendFen:null,
    notice:'文件不含商品ID；净成交是笔数，不是手套件数。净数据后续仍可能回补。'};
}
