import { chromium } from 'playwright-core';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { isMerchantUrl, collectPromotionDocument } from './promotion-reader.mjs';

// Dedicated profile only. Never attach to a daily-use Chrome or export cookies.
export function createBrowserConnection(options = {}) {
  let context=null, opening=null;
  const profile=options.profile || join(process.env.LOCALAPPDATA || join(homedir(),'.local','share'),'Xinyongtu','EdgeProfile');
  const settings=options.launchOptions || {channel:'msedge',headless:false};
  const landing=options.landing || 'https://mms.pinduoduo.com/';
  async function status(){
    if(!context)return {connected:false,loginVerified:false,message:'专用浏览器未连接'};
    const pages=context.pages();
    const merchantPages=pages.filter(p=>isMerchantUrl(p.url()));
    return {connected:true,loginVerified:false,pageCount:pages.length,merchantPageCount:merchantPages.length,
      message:merchantPages.length?'已连接商家站点页面，登录状态尚未验证':'浏览器已连接，请在专用窗口打开商家后台'};
  }
  async function open(){
    if(opening)return opening;
    if(context){const page=context.pages()[0];if(page)await page.bringToFront();return status();}
    opening=(async()=>{
      try{
        const launched=await chromium.launchPersistentContext(profile,settings);
        context=launched;launched.on('close',()=>{if(context===launched)context=null});
        const page=launched.pages()[0] || await launched.newPage();
        await page.goto(landing,{waitUntil:'domcontentloaded',timeout:30000}).catch(()=>{});
        return status();
      }catch(error){
        const detail=String(error?.message||'');
        const missing=/not found|doesn't exist|ENOENT|not exist/i.test(detail);
        const locked=/ProcessSingleton|profile.*in use|user data directory.*in use/i.test(detail);
        const failure=new Error(missing?'未找到 Microsoft Edge。请确认电脑已安装 Edge。':locked?'专用浏览器配置正在使用中。请先关闭其他新龙图专用窗口，再重试。':'Edge 启动失败，本机服务仍可用。请提供启动命令窗口中的提示以继续排查。');
        failure.code=missing?'BROWSER_NOT_FOUND':locked?'PROFILE_IN_USE':'BROWSER_LAUNCH_FAILED';
        throw failure;
      }finally{opening=null;}
    })();return opening;
  }
  async function close(){if(opening)await opening.catch(()=>{});if(context)await context.close();return status();}
  async function snapshot(){
    if(!context)throw new Error('请先启动专用浏览器，并手动打开多多招财页面。');
    const matches=[];
    for(const page of context.pages())for(const frame of page.frames()){
      if(!isMerchantUrl(frame.url()))continue;
      try{
        const result=await frame.evaluate(collectPromotionDocument);
        if(result.recognized)matches.push({...result,origin:new URL(frame.url()).origin});
      }catch{/* Detached or navigating frames cannot establish a usable snapshot. */}
    }
    if(matches.length!==1)throw new Error(matches.length?'检测到多个推广页面，请仅保留一个待采集的多多招财标签页，再重试。':'未找到可识别的推广页面。请完成登录，在专用浏览器打开多多招财，并将需要采集的数据卡片显示在窗口内。');
    return {...matches[0],capturedAt:new Date().toISOString(),readOnly:true};
  }
  return {open,status,close,snapshot};
}
