import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {join} from 'node:path';

export function edgeCandidates(env=process.env){
  return [...new Set([env['ProgramFiles(x86)'],env.ProgramFiles,env.LOCALAPPDATA].filter(Boolean)
    .map(root=>join(root,'Microsoft','Edge','Application','msedge.exe')))];
}

export function openWorkbench(url, options={}){
  const platform=options.platform||process.platform;
  const launch=options.spawn||spawn,exists=options.existsSync||existsSync;
  const report=options.report||console.error;
  const parsed=new URL(url);
  if(parsed.protocol!=='http:' || parsed.hostname!=='127.0.0.1' || parsed.pathname!=='/')throw new Error('Invalid workbench URL');
  if(platform!=='win32')return false;
  const executable=edgeCandidates(options.env||process.env).find(exists);
  if(!executable){report('Microsoft Edge was not found. Open the printed workbench URL manually in Edge.');return false;}
  const child=launch(executable,[url],{stdio:'ignore'});
  child.on('error',()=>report('Could not open Microsoft Edge. Open the printed workbench URL manually in Edge.'));
  return true;
}
