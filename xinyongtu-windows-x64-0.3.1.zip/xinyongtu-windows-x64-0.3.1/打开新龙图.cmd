@echo off
title Xinyongtu v0.3.1 - Microsoft Edge
setlocal
cd /d "%~dp0"
if not exist "runtime\node.exe" (
  echo Missing bundled runtime. Extract the complete portable ZIP first.
  pause
  exit /b 1
)
"runtime\node.exe" start-portable.mjs
if errorlevel 1 pause
