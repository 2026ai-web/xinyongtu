import {openWorkbench} from './open-workbench.mjs';

console.log('Xinyongtu v0.3.1 | Microsoft Edge edition');
console.log('Folder: '+process.cwd());
const url='http://127.0.0.1:17411/';
let existing=false;
let runningVersion=null;
try {
  const response=await fetch(url+'api/health',{signal:AbortSignal.timeout(1200)});
  const health=await response.json();
  if(health.app==='xinyongtu-local-workbench')runningVersion=health.version;
  existing=response.ok && health.app==='xinyongtu-local-workbench' && health.version==='0.3.1' && health.ready===true;
}catch{}
if(runningVersion && !existing){
  console.error(`An older/different workbench (${runningVersion}) is still running on port 17411. Close its terminal, then run this launcher again. The new version has NOT started.`);
  process.exitCode=1;
}else if(existing){
  console.log('Workbench is already running. Opening existing window.');
  openWorkbench(url);
}else{
  process.env.PORT='17411';
  process.argv.push('--open');
  await import('./server.mjs');
}
