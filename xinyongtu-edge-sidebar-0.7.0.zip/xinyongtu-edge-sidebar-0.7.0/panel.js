import {collectPromotionDocument,isMerchantUrl} from './reader.js';
import {collectAutomatically} from './auto-collector.js';
import {createSnapshotJournal} from './snapshot-quality.js';
const journal=createSnapshotJournal();let latestAttempt=null,currentAssessment=null;
const $=id=>document.getElementById(id);let snapshot=null,revision=0,targetTab=null;
let automatic=false,controller=null,timer=null,autoEpoch=0;
function node(tag,text){const e=document.createElement(tag);e.textContent=text;return e;}
function reset(message='页面已改变，请重新采集。'){
 revision++;snapshot=null;$('results').hidden=true;$('export').disabled=true;$('status').textContent=message;
}
function renderSnapshot(data){
 snapshot=data;const auto=data.autoCollection;$('coverage').textContent=auto?'已采商品：'+auto.capturedRows+'/'+(auto.expectedRows??'总数未识别')+'；'+(auto.rowCoverageConfirmed?'当前筛选行数覆盖已核对':'行数覆盖未确认')+'；'+(auto.fieldsComplete?'字段齐全':'仍有缺失字段')+'；日期范围：'+(auto.dateRangeVerified?'已核对控件值':'未完全核对')+'。停止原因：'+auto.stopReason+'。仅列表数据，不含单品详情。':'';$('results').hidden=false;$('time').textContent='本轮结束时间：'+new Date(data.capturedAt).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'})+'（北京时间）';
 const ds=data.dateScopes||{};$('dates').textContent='推广统计日期：'+((ds.primary||[]).join('、')||'未可靠识别')+'；对比日期：'+((ds.comparison||[]).join('、')||'未识别')+'；辅助模块日期：'+((ds.auxiliary||[]).join('、')||'无')+'（不作为推广范围）。';
 const asOf=data.dataAsOf||{};
 $('asOf').textContent='当前日截止：'+((asOf.currentCutoffs||[]).join('、')||'未识别')+'；对比日截止：'+((asOf.comparisonCutoffs||[]).join('、')||'未识别')+'。'+(asOf.cutoffAlignment==='different'?'时点不同，不能直接同比。':asOf.cutoffAlignment==='same'?'时点一致，仍需核对统计范围。':'截止时点无法完整核对。');
 $('productScope').textContent=data.productScope||'尚未识别商品行';$('products').replaceChildren();
 for(const product of data.products||[]){
  const block=document.createElement('div');block.className='product';if((data.conflictProductIds||[]).includes(product.productId))block.append(node('p','此商品扫描期间数据变化，存在冲突，不可用于计算。'));block.append(node('h3','商品 ID：'+product.productId));
  block.append(node('p','状态：'+(product.status||'未识别')+' · 预算：'+(product.budget?product.budget.display+(product.budget.kind==='amount'?' 元':''):'未识别')+' · 净目标投产比：'+(product.targetNetRoas||'未识别')));
  const list=document.createElement('dl');for(const field of product.metrics){list.append(node('dt',field.label),node('dd',product.interpretations?.[field.label]?.state==='not_applicable'?'—（无净成交）':field.current));}block.append(list);
  block.append(node('p',product.metrics.length?'同行指标待核对；不能与顶部汇总合并。':'未匹配到可靠列头，未猜测这条商品的花费或成交数据。'));
  block.append(node('p','本次缺失：'+product.missingFields.join('、')));$('products').append(block);
 }
 if(!(data.products||[]).length)$('products').append(node('p','当前未识别商品行，覆盖未确认；请导出结果供排查。'));
 for(const row of data.pendingRows||[])$('products').append(node('p','待核对：'+row.reason));
 const counts=Object.create(null);for(const m of data.metrics)counts[m.label]=(counts[m.label]||0)+1;
 $('metrics').replaceChildren();
 for(const m of data.metrics){const tr=document.createElement('tr');for(const v of[m.label,m.current,counts[m.label]>1?'多个候选，不可合并':'待人工核对'])tr.append(node('td',v));$('metrics').append(tr);}
 $('warnings').replaceChildren();
 if(!data.metrics.length)$('warnings').append(node('p','页面已识别，但未解析到数据卡片。请将指标显示在窗口中再试，不会将缺失值记成零。'));
 for(const warning of data.warnings)$('warnings').append(node('p',warning));
 for(const c of data.conflictRecords||[])$('warnings').append(node('p','冲突商品 '+c.productId+' / '+c.field+'：'+JSON.stringify(c.before.value)+'（'+c.before.observedAt+'）→ '+JSON.stringify(c.after.value)+'（'+c.after.observedAt+'）；原因未定。'));
 $('export').disabled=false;
}
function display(data){
 const record=journal.record(data,targetTab);latestAttempt=record.latestAttempt;currentAssessment=record.assessment;
 const displayed=record.lastQualified||latestAttempt;renderSnapshot(displayed);
 $('resultHeading').textContent=record.promoted?'本轮结构检查合格 · 待人工核对':record.lastQualified?'保留上轮结构合格结果 · 非本轮实时数据':'本轮诊断结果 · 未通过结构检查';
 $('attemptStatus').textContent='本轮 '+new Date(data.capturedAt).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'})+'：'+(record.promoted?'结构检查通过；不代表店铺、利润或结算已验证。':record.assessment.problems.join('；')+'。'+(record.lastQualified?'没有覆盖上轮合格结果。':'当前没有同范围的合格快照。'));
 $('exportAttempt').disabled=false;
}
$('read').onclick=async()=>{
 reset('正在只读采集当前标签页…');const ticket=revision;$('read').disabled=true;
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!isMerchantUrl(tab.url))throw Error('请先选中日常 Edge 中的拼多多商家后台或多多招财标签页，再点击采集。');
  if(tab.status==='loading')throw Error('页面正在加载，请稍后重试。');
  targetTab=tab.id;
  const results=await chrome.scripting.executeScript({target:{tabId:tab.id,allFrames:true},func:collectPromotionDocument});
  if(ticket!==revision)return;
  const current=await chrome.tabs.get(tab.id);
  if(current.url!==tab.url||current.status==='loading')throw Error('页面已跳转，请加载完成后重新采集。');
  const recognized=results.map(r=>r.result).filter(r=>r?.recognized);
  if(!recognized.length)throw Error('未识别到可见的多多招财数据。请确认已登录，打开“商品推广”，并将数据卡片显示在当前窗口。');
  if(recognized.length!==1)throw Error('页面存在多个推广区域，暂不自动合并。请只显示一个待核对的推广页面后重试。');
  display({...recognized[0],capturedAt:new Date().toISOString(),readOnly:true,source:'daily-edge-sidebar',origin:new URL(tab.url).origin});
  $('status').textContent='采集完成，数据待核对；没有修改推广。';
 }catch(e){if(ticket===revision)$('status').textContent=/Cannot access|permission|Extension manifest/i.test(e.message)?'无法读取此页面。请确认扩展已获得拼多多站点权限；扩展更新后请刷新推广标签页再试。':e.message;}
 finally{$('read').disabled=false;}
};
$('clear').onclick=()=>{stopAutomatic('本次数据已清除。');journal.clear();latestAttempt=null;currentAssessment=null;$('exportAttempt').disabled=true;$('attemptStatus').textContent='本轮与合格快照已清除。';reset('本次数据已清除。');};
function download(data,name){
 if(!data)return;const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
 const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
$('export').onclick=()=>download(snapshot,'xinyongtu-displayed-snapshot.json');
$('exportAttempt').onclick=()=>download(latestAttempt,'xinyongtu-latest-attempt-diagnostic.json');
chrome.tabs.onActivated.addListener(()=>{stopAutomatic('当前标签页已切换，自动采集已停止。');reset('当前标签页已切换，请重新采集。');});
chrome.tabs.onUpdated.addListener((id,change)=>{if(id===targetTab&&(change.status==='loading'||change.url)){stopAutomatic('页面正在跳转，自动采集已停止。');reset('推广页面已跳转或刷新，请重新采集。');}});

function stopAutomatic(message='自动采集已停止。'){
 autoEpoch++;automatic=false;clearTimeout(timer);timer=null;controller?.abort();$('auto').disabled=false;$('stop').disabled=true;$('read').disabled=false;$('interval').disabled=false;$('status').textContent=message;
}
async function runCycle(expectedEpoch=autoEpoch){
 if(!automatic||expectedEpoch!==autoEpoch)return;const runEpoch=expectedEpoch;controller=new AbortController();$('status').textContent='正在自动采集，请暂时不要切换标签、日期、筛选条件或手动操作页面。';
 try{
  const data=await collectAutomatically({tabId:targetTab,signal:controller.signal,progress:p=>{$('progress').textContent='扫描中：'+p.count+'/'+(p.expected??'总数未知')+' 条；扫描步数 '+p.steps+'；向后扫描页数 '+p.pages;}});
  if(!automatic||runEpoch!==autoEpoch)return;display(data);$('status').textContent='本轮扫描结束，未修改广告。覆盖范围请看结果说明。';
  if(!currentAssessment.accepted){stopAutomatic('本轮未通过结构检查，已暂停重复采集；请导出本轮诊断。上轮合格结果未被覆盖。');return;}
  const seconds=Number($('interval').value);
  if(seconds>0){$('progress').textContent='本轮'+data.products.length+'条；约'+seconds+'秒后重新读取平台已加载数据（不强制刷新页面）。';timer=setTimeout(()=>runCycle(runEpoch),seconds*1000);}
  else stopAutomatic('单轮自动扫描已结束，请核对结果。');
 }catch(e){if(automatic&&runEpoch===autoEpoch)stopAutomatic(e.message);}
}
$('auto').onclick=async()=>{
 stopAutomatic();reset('正在准备自动采集…');
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 if(!tab?.id||!isMerchantUrl(tab.url)){$('status').textContent='请先选中正常登录的多多招财标签页。';return;}
 targetTab=tab.id;automatic=true;$('auto').disabled=true;$('stop').disabled=false;$('read').disabled=true;$('interval').disabled=true;runCycle();
};
$('stop').onclick=()=>stopAutomatic();
window.addEventListener('pagehide',()=>{automatic=false;controller?.abort();clearTimeout(timer);});
