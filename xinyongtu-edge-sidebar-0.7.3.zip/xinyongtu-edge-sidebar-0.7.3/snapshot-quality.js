// Structural acceptance only. It does not verify shop identity or authorize ad changes.
export function assessSnapshot(data){
 const problems=[],a=data?.autoCollection,rows=data?.products||[];
 const managed=data?.activeMode==='全店托管';
 const fields=managed?['交易额(元)','净交易额(元)','净成交笔数','曝光量','点击量']:['成交花费(元)','交易额(元)','实际投产比','总花费(元)','净交易额(元)','净实际投产比','净成交笔数','每笔净成交花费(元)','曝光量','点击量'];
 if(!a)problems.push('不是完整自动扫描结果');
 if(!a?.scanCompleted)problems.push('扫描没有正常完成');
 if(!a?.rowCoverageConfirmed||!Number.isInteger(a?.expectedRows)||rows.length!==a.expectedRows)problems.push('商品行数覆盖未确认');
 if(new Set(rows.map(r=>r.productId)).size!==rows.length)problems.push('存在重复商品ID');
 if(data?.conflictProductIds?.length||data?.conflictRecords?.length)problems.push('存在未解决的采集冲突');
 if(!a?.dateRangeVerified||!data?.dateScopes?.primaryVerified)problems.push('推广统计日期未可靠识别');
 if(!['稳定成本推广','全店托管'].includes(data?.activeMode))problems.push('推广模式未可靠识别');
 if(!a?.fieldsComplete||!rows.length||rows.some(r=>r.missingFields.length))problems.push('存在缺失字段');
 if(rows.some(r=>!r.singleObservationComplete))problems.push('缺少单次完整行观测');
 if(rows.some(r=>!/^\d{6,20}$/.test(r.productId)||(!managed&&(!r.budget||!r.status||!/^\d+(?:\.\d+)?$/.test(r.targetNetRoas||'')))||fields.some(label=>r.metrics?.filter(m=>m.label===label&&(/曝光量|点击量|成交笔数/.test(label)?/^\d[\d,]*(?:\.\d+)?(?:万|亿)?$/:/^-?\d[\d,]*(?:\.\d+)?$/).test(m.current)).length!==1)))problems.push('商品字段格式或唯一性检查失败');
 if(managed&&(!data.managedSettings?.budget||!/^\d+(?:\.\d+)?$/.test(data.managedSettings?.targetNetRoas||'')))problems.push('托管总预算或总目标投产比未识别');
 if(managed&&['总花费(元)','净交易额(元)'].some(label=>data.metrics?.filter(m=>m.scope==='managed-summary'&&m.label===label).length!==1))problems.push('托管汇总范围未唯一识别');
 if(data?.pendingRows?.length)problems.push('存在未解析商品行');
 return {accepted:problems.length===0,problems,meaning:'仅结构检查合格，尚未验证店铺身份、最终结算或利润。'};
}
export function createSnapshotJournal(){
 const qualified=new Map();let latest=null;
 const key=(data,session)=>JSON.stringify({session,origin:data.origin||'',dates:data.selectedDateRange||[],filter:data.scopeFingerprint||'',mode:data.activeMode||'unknown'});
 return {
  record(data,session){
   const assessment=assessSnapshot(data),scope=key(data,session);latest={...structuredClone(data),qualityAssessment:assessment};
   if(assessment.accepted){qualified.set(scope,structuredClone(latest));if(qualified.size>10)qualified.delete(qualified.keys().next().value);}
   return {assessment,latestAttempt:latest,lastQualified:qualified.get(scope)||null,promoted:assessment.accepted};
  },
  clear(){qualified.clear();latest=null;},
 };
}
